<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Produk;
use DB;

class ProdukSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Produk::create([
            'namaProduk' => 'komputer',
            'deskripsiProduk' => 10,
            'hargaProduk' => 10000,
            'kategoriProduk' => 1,
        ]);

        Produk::create([
            'namaProduk' => 'kulkas',
            'deskripsiProduk' => 20,
            'hargaProduk' => 20000,
            'kategoriProduk' => 2,
        ]);

        Produk::create([
            'namaProduk' => 'iphone',
            'deskripsiProduk' => 30,
            'hargaProduk' => 30000,
            'kategoriProduk' => 3,
        ]);
    }
}
